# Put your font files here

Drop `.ttf` or `.otf` files into this folder. The app will pass this folder to FFmpeg as the fonts directory, so whatever fonts you bundle will be available.

Required (to match the dropdown in the UI):
- `TheBoldFont.ttf`
- `Montserrat-Black.ttf`   ← free: https://fonts.google.com/specimen/Montserrat
- `IntegralCF-Bold.otf`

If your font's internal family name differs from the dropdown label, you can either:
- edit the `<option value="...">` in `templates/index.html` to match the font's real family name, or
- rename the font's internal family using a tool like FontForge.

Check a font's internal family name with: `fc-query font.ttf | grep family`
