# Subtitle Burner 🎬

A drag-and-drop web app that adds word-by-word highlighted captions to your videos (TikTok/Reels-style karaoke captions) using **Whisper** for transcription and **FFmpeg** for rendering. Built to run on **Replit**.

## Features

- 🎯 **Word-level highlighting** — 2–3 words on screen, the current word highlighted
- 🎨 **7 preset color themes** + full custom color pickers
- 🔠 **3 fonts**: The Bold Font, Montserrat Black, Integral CF (add your own .ttf/.otf to `/fonts`)
- 📏 **Adjustable size, position, outline, drop shadow**
- 🔤 **ALL CAPS toggle**
- 🖱️ **Drag-and-drop upload**
- ⬇ **Download finished video**

## 🚨 IMPORTANT: Add your font files before running

This app uses three fonts that must be **licensed and downloaded by you** — they are not bundled.

1. Get the `.ttf` or `.otf` files for:
   - **The Bold Font** — https://thebold.net/
   - **Montserrat Black** — free from Google Fonts: https://fonts.google.com/specimen/Montserrat
   - **Integral CF** — https://www.fontfabric.com/fonts/integral-cf/
2. Drop each font file into the `fonts/` folder of this project.
3. The PostScript/family name inside the font file must match what's in the dropdown. If your file's internal family name differs (e.g. "Montserrat" instead of "Montserrat Black"), edit `templates/index.html` and `app.py` to match, or rename the font's internal name with a font editor.

> **Tip:** To check a font's internal family name on Linux, run `fc-query /path/to/font.ttf | grep family`. On macOS, open Font Book and look at the family name.

## Running on Replit

1. Create a new Replit and import this project (or upload the folder).
2. Add your font files to `fonts/` (see above).
3. Hit **Run**. On first run, Replit will:
   - Install FFmpeg via Nix (`replit.nix`)
   - Install Python deps from `requirements.txt`
   - Download the Whisper `base` model on the first transcription (~140 MB)
4. Open the webview, drop in a video, customize, and click **Generate Captions**.

## Running locally

```bash
# 1. Install FFmpeg (macOS example)
brew install ffmpeg

# 2. Install deps
pip install -r requirements.txt

# 3. Add fonts to ./fonts/ (see above)

# 4. Run
python app.py
# Visit http://localhost:5000
```

## How it works

1. **Upload** — Video saved to `uploads/` with a UUID name.
2. **Transcribe** — `faster-whisper` extracts word-level timestamps.
3. **Build subtitles** — Words chunked into groups (default 3). For each word's time range, an ASS subtitle line is emitted where that word is colored with the highlight color and the others use the primary color.
4. **Burn** — FFmpeg's `subtitles` filter burns the ASS file into the video, using your local `fonts/` directory so bundled fonts are found.

## Tweaks & Tips

- **Faster transcription:** change `WhisperModel("base", ...)` in `app.py` to `"tiny"` (faster, less accurate) or `"small"`/`"medium"` (slower, more accurate).
- **Replit resource limits:** the free Replit tier may struggle with large videos or the bigger Whisper models. Keep videos under ~2 minutes and stick with `base` or `tiny`.
- **Long videos:** bump `MAX_CONTENT_LENGTH` in `app.py`.
- **More fonts:** drop any `.ttf`/`.otf` into `fonts/` and add an `<option>` to the `<select id="font">` in `templates/index.html`.
- **Different grouping:** the "Words per group" slider lets you show 1–5 words at a time. 1 = only the current word.

## Project structure

```
subtitle-app/
├── app.py                 # Flask server, Whisper, ASS generation, FFmpeg
├── requirements.txt
├── .replit                # Replit run config
├── replit.nix             # FFmpeg + fontconfig
├── templates/
│   └── index.html
├── static/
│   ├── app.js
│   └── style.css
├── fonts/                 # ← put your .ttf/.otf here
├── uploads/               # (auto-created)
└── outputs/               # (auto-created)
```

## License / credits

- Your code is yours.
- **Fonts**: respect each font's license. Montserrat is SIL OFL (free). The Bold Font and Integral CF are commercial — don't redistribute the files.
- Whisper model is MIT.
